document.addEventListener('DOMContentLoaded', () => {
    const btnOrdersPlaced = document.getElementById('btn-orders-placed');
    const btnOrdersReceived = document.getElementById('btn-orders-received');
    const ordersPlacedList = document.getElementById('orders-placed-list');
    const ordersReceivedList = document.getElementById('orders-received-list');

    btnOrdersPlaced.addEventListener('click', () => {
        btnOrdersPlaced.classList.add('active');
        btnOrdersReceived.classList.remove('active');
        ordersPlacedList.style.display = '';
        ordersReceivedList.style.display = 'none';
    });

    btnOrdersReceived.addEventListener('click', () => {
        btnOrdersReceived.classList.add('active');
        btnOrdersPlaced.classList.remove('active');
        ordersReceivedList.style.display = '';
        ordersPlacedList.style.display = 'none';
    });
});
